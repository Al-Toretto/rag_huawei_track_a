#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
PYTHON_BIN="${PYTHON_BIN:-python3}"
MODEL_NAME="${MODEL_NAME:-mistralai/Mistral-7B-Instruct-v0.2}"
DATASET_PATH="${DATASET_PATH:-$SCRIPT_DIR/inputs/musique_s.json}"
KV_STORAGE_SIZE="${KV_STORAGE_SIZE:-30GB}"
KV_CHUNK_SIZE="${KV_CHUNK_SIZE:-256}"
QPS="${QPS:-3.5}"
BASE_URL="${BASE_URL:-http://localhost:8000/v1}"
API_KEY="${API_KEY:-EMPTY}"
END_INDEX="${END_INDEX:-}"
MAX_TOKENS="${MAX_TOKENS:-32}"
BLEND_SEPARATOR="${BLEND_SEPARATOR:- # # }"

check_endpoint() {
    if ! "$PYTHON_BIN" - <<'PY' "$BASE_URL"; then
import sys
from urllib.error import URLError
from urllib.request import urlopen

base_url = sys.argv[1].rstrip("/")
try:
    with urlopen(f"{base_url}/models", timeout=5) as response:
        if response.status >= 400:
            raise RuntimeError(f"HTTP {response.status}")
except (URLError, RuntimeError) as exc:
    print(
        f"Serving endpoint is not reachable at {base_url}/models: {exc}",
        file=sys.stderr,
    )
    raise SystemExit(1)
PY
        exit 1
    fi
}

infer_prompt_build_method() {
    local dataset_basename
    dataset_basename=$(basename "$1" | tr '[:upper:]' '[:lower:]')
    case "$dataset_basename" in
        *samsum*|*multinews*)
            echo "FEW_SHOT"
            ;;
        *)
            echo "QA"
            ;;
    esac
}

PROMPT_BUILD_METHOD="${PROMPT_BUILD_METHOD:-$(infer_prompt_build_method "$DATASET_PATH")}"
DATASET_NAME=$(basename "$DATASET_PATH")
DATASET_NAME="${DATASET_NAME%.*}"
OUTPUT_FILE="${OUTPUT_FILE:-${DATASET_NAME}_lmcache_qps_${QPS}.csv}"

check_endpoint

PRECOMPUTE_ARGS=(
    "$SCRIPT_DIR/precompute.py"
    --model "$MODEL_NAME"
    --dataset "$DATASET_PATH"
    --prompt-build-method "$PROMPT_BUILD_METHOD"
    --kv-chunk-size "$KV_CHUNK_SIZE"
    --base-url "$BASE_URL"
    --api-key "$API_KEY"
)

if [[ -z "$END_INDEX" && -n "$KV_STORAGE_SIZE" ]]; then
    PRECOMPUTE_ARGS+=(--kv-storage-size "$KV_STORAGE_SIZE")
fi

if [[ -n "$END_INDEX" ]]; then
    PRECOMPUTE_ARGS+=(--end-index "$END_INDEX")
fi

log_str=$("$PYTHON_BIN" "${PRECOMPUTE_ARGS[@]}")
echo "$log_str"
RETURNED_END_INDEX=$(awk '/^Precompute from /{print $5}' <<<"$log_str" | tail -n1)

if [[ -z "$RETURNED_END_INDEX" ]]; then
    echo "Precompute returned an empty end index"
    exit 1
fi

"$PYTHON_BIN" "$SCRIPT_DIR/rag.py" \
    --qps "$QPS" \
    --model "$MODEL_NAME" \
    --dataset "$DATASET_PATH" \
    --end-index "$RETURNED_END_INDEX" \
    --separator "$BLEND_SEPARATOR" \
    --prompt-build-method "$PROMPT_BUILD_METHOD" \
    --base-url "$BASE_URL" \
    --api-key "$API_KEY" \
    --max-tokens "$MAX_TOKENS" \
    --output "$OUTPUT_FILE"
